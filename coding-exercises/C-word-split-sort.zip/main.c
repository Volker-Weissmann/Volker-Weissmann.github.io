#include "word_sort.c"
int main()
{
    unit_tests();
    return 0;
}
