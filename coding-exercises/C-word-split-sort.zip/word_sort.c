// Running unittests:
// gcc -g -fsanitize=undefined,address -Wall -Wextra main.c && ./a.out
// or
// clang -g -fsanitize=undefined,address -Wall -Wextra main.c && ./a.out

// Running the fuzzer:
// clang -g -O3 -fsanitize=undefined,address,fuzzer -Wall -Wextra word_sort.c && ./a.out

// Note about my style: I have used unsigned int everywhere instead of size_t or
// usize_t since the word_sort signature uses it.

// I assume that you will run my code on Linux. I have not tested my code on
// Windows. This post:
// https://stackoverflow.com/questions/3694723/error-c3861-strcasecmp-identifier-not-found-in-visual-studio-2008
// suggests that I need to use _stricmp instead of strcasecmp. Alternatively I
// could write strcasecmp myself, or adopt it from
// https://code.woboq.org/userspace/glibc/string/strcasecmp.c.html .

#include "word_sort.h"
#include <assert.h>
#include <ctype.h>
#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

// adopted from https://stackoverflow.com/questions/3536153/c-dynamically-growing-array
typedef struct {
    char** array;
    unsigned int used;
    unsigned int capacity;
} Array;

void initArray(Array* a, unsigned int initialCapacity)
{
    a->array = malloc(initialCapacity * sizeof(char*));
    assert(a->array != NULL);
    a->used = 0;
    a->capacity = initialCapacity;
}

void insertArray(Array* a, char* element)
{
    if (a->used == a->capacity) {
        a->capacity *= 2;
        a->array = realloc(a->array, a->capacity * sizeof(char*));
        assert(a->array != NULL);
    }
    a->array[a->used++] = element;
}

void freeArray(Array* a)
{
    assert(a->array != NULL);
    free(a->array);
    a->array = NULL;
    a->used = a->capacity = 0;
}

int compare_alphabetical_case_sensitiv(const void* a_ptr, const void* b_ptr)
{
    const char* a_str = *(char**)a_ptr;
    const char* b_str = *(char**)b_ptr;
    return strcmp(a_str, b_str);
}

int compare_alphabetical_case_insensitiv(const void* a_ptr, const void* b_ptr)
{
    const char* a_str = *(char**)a_ptr;
    const char* b_str = *(char**)b_ptr;
    return strcasecmp(a_str, b_str);
}

unsigned int word_sort(const char* src, char* dst, unsigned int dst_len, unsigned int flags)
{
    bool reverse = flags & WORD_SORT_REVERSE;
    bool ignore_case = flags & WORD_SORT_IGNORE_CASE;

    // Create a writable copy wsrc of src. We will later replace some whitespace
    // characters in wsrc with null terminators. Other than that, the two arrays
    // will be identical
    unsigned int input_strlen = strlen(src);
    char* wsrc = malloc((input_strlen + 1));
    assert(wsrc != NULL);
    strcpy(wsrc, src);

    Array words;
    initArray(&words, 16);

    unsigned int left = 0;
    unsigned int right = 0;
    while (src[right] != '\0') {
        while (isspace(src[left]) && src[left] != '\0') {
            left++;
        }
        if (src[left] == '\0') {
            break;
        }
        right = left;
        while (!isspace(src[right]) && src[right] != '\0') {
            right++;
        }
        wsrc[right] = '\0';
        // The word starts at wsrc + left and ends with a null terminator at wsrc + right
        insertArray(&words, wsrc + left);
        left = right;
    }

    if (ignore_case) {
        qsort(words.array, words.used, sizeof(char*), compare_alphabetical_case_insensitiv);
    } else {
        qsort(words.array, words.used, sizeof(char*), compare_alphabetical_case_sensitiv);
    }

    if (dst_len == 0) {
        freeArray(&words);
        free(wsrc);
        return 0;
    }
    dst[0] = '\0';
    unsigned int bytes_written = 1;
    for (unsigned int u = 0; u < words.used; u++) {
        char* word = words.array[reverse ? words.used - u - 1 : u];
        unsigned int word_strlen = strlen(word);
        int space_len = u != 0;
        if (bytes_written + space_len + word_strlen > dst_len) {
            // Returning 0 indicates to the caller that there is insufficient
            // space. If the caller reads half of the "real" solution this might
            // lead to hard to find bugs. So we clear it.
            memset(dst, '\0', dst_len);
            freeArray(&words);
            free(wsrc);
            return 0;
        }
        memset(dst + bytes_written - 1, ' ', space_len);
        strcpy(dst + bytes_written - 1 + space_len, word);
        bytes_written += space_len + word_strlen;
    }

    freeArray(&words);
    free(wsrc);
    return bytes_written;
}

void test_word_sort(unsigned int flags, const char* src, const char* dst_sol, unsigned int bytes_written_sol)
{
    unsigned int dst_len = 100;
    char* dst = alloca(dst_len);

    unsigned int bytes_written = word_sort(src, dst, dst_len, flags);
    assert(bytes_written == bytes_written_sol);
    assert(strcmp(dst, dst_sol) == 0);
}

void unit_tests()
{
    // We have a fuzzer, so we do not need that many unit tests. I've wrote some anyway.

    // Examples from the documentation of test_word_sort
    test_word_sort(0, "The   \t\n cat  sat", "The cat sat", 12);
    test_word_sort(WORD_SORT_IGNORE_CASE, "The   \t\n cat  sat", "cat sat The", 12);
    test_word_sort(WORD_SORT_REVERSE, "The   \t\n cat  sat", "sat cat The", 12);

    // Other test cases

    unsigned int dst_len = 50;
    char* dst = alloca(dst_len);
    unsigned int bytes_written;

    bytes_written = word_sort("", dst, 0, 0);
    assert(bytes_written == 0);

    test_word_sort(0, "  The   \t\n cat  sat  ", "The cat sat", 12);
    test_word_sort(0, "", "", 1);
    test_word_sort(0, "  \t\n  ", "", 1);
    test_word_sort(0, "  \t\nk  ", "k", 2);
    test_word_sort(0, "abc", "abc", 4);
    test_word_sort(0, "b a c", "a b c", 6);
    test_word_sort(0, "b a a", "a a b", 6);

    bytes_written = word_sort("F f", dst, dst_len, WORD_SORT_IGNORE_CASE);
    assert(bytes_written == 4);
    assert(strcmp(dst, "F f") == 0 || strcmp(dst, "f F") == 0);

    bytes_written = word_sort("F f", dst, dst_len, WORD_SORT_IGNORE_CASE | WORD_SORT_REVERSE);
    assert(bytes_written == 4);
    assert(strcmp(dst, "F f") == 0 || strcmp(dst, "f F") == 0);

    bytes_written = word_sort("1234567890 1234567890 1234567890 1234567890 1234567890", dst, dst_len, 0);
    assert(bytes_written == 0);

    bytes_written = word_sort("1234567890 1234567890 1234567890 1234567890                ", dst, dst_len, 0);
    assert(bytes_written == 44);
    assert(strcmp(dst, "1234567890 1234567890 1234567890 1234567890") == 0);
}

// Returns the number of `c`'s in the string `str`.
unsigned int count_occurences(const char* str, char c)
{
    unsigned int count = 0;
    for (const char* ptr = str; *ptr != '\0'; ptr++) {
        if (*ptr == c) {
            count++;
        }
    }
    return count;
}

// Returns the number of whitespaces in the string `str`.
unsigned int count_whitespaces(const char* str)
{
    unsigned int count = 0;
    for (const char* ptr = str; *ptr != '\0'; ptr++) {
        if (isspace(*ptr)) {
            count++;
        }
    }
    return count;
}

int LLVMFuzzerTestOneInput(const char* data, size_t size)
{
    if (size < sizeof(unsigned int) * 2 + 1) {
        return 0;
    }
    unsigned int* flags = (unsigned int*)data;
    unsigned int dst_len = *(((unsigned int*)data) + 1);
    dst_len &= 0xFFFFF; // We don't want to allocate too much memory and get out-of-memory errors.
    char* dst = malloc(dst_len);
    assert(dst != NULL);

    // If there is a way to tell the Fuzzer that we always want a null
    // terminator that would be more performant than allocation and copying.
    char* src = malloc(size - sizeof(unsigned int) * 2 + 1);
    assert(src != NULL);
    memcpy(src, data, size - sizeof(unsigned int) * 2);
    src[size - sizeof(unsigned int) * 2] = '\0';

    unsigned int bytes_written = word_sort(src, dst, dst_len, *flags);
    if (bytes_written == 0) {
        assert(dst_len < strlen(src) + 1);
    } else {
        assert(bytes_written <= dst_len);
        assert(bytes_written == strlen(dst) + 1);
        assert(bytes_written <= strlen(src) + 1);
        assert(bytes_written - count_whitespaces(dst) == strlen(src) - count_whitespaces(src) + 1);
        // I know the assertion below is implied by the two assertions above, but I added it
        // anyway to make it easier to reason about it
        assert(count_whitespaces(src) >= count_whitespaces(dst));
        assert(count_occurences(src, 'k') == count_occurences(dst, 'k'));
        assert(2 * count_whitespaces(dst) <= strlen(dst));

        unsigned char last = 0;
        if (*flags & WORD_SORT_REVERSE) {
            last = 255;
        }
        for (unsigned int u = 0; u < bytes_written - 1; u++) {
            if (isspace(dst[u]) || dst[u] == '\0') {
                unsigned char cur = dst[u + 1];
                if (*flags & WORD_SORT_IGNORE_CASE) {
                    cur = tolower(cur);
                }
                if (*flags & WORD_SORT_REVERSE) {
                    assert(cur <= last);
                } else {
                    assert(cur >= last);
                }
                last = cur;
            }
        }

        if (!(*flags & WORD_SORT_IGNORE_CASE)) {
            // Check if word_sort is idempotent
            // Since sorting is not stable, it might not be idempotent if we ignore case.
            char* new_dst = malloc(bytes_written);
            assert(new_dst != NULL);
            unsigned int new_bytes_written = word_sort(dst, new_dst, bytes_written, *flags);
            assert(new_bytes_written == bytes_written);
            assert(strcmp(dst, new_dst) == 0);
            free(new_dst);
        }
    }

    free(dst);
    free(src);
    return 0;
}
